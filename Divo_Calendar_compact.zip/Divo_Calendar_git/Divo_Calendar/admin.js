'use strict';

const el = id => document.getElementById(id);
const types = {
  event: 'Calendar event', birth: 'Artist profile / birthday',
  music: 'Music release', film: 'Movie release', milestone: 'Career milestone'
};
const entry = el('entry');
const workspace = el('workspace');
const pageSize = 25;
let key = '';
let records = [];
let fields = [];
let current = null;
let page = 0;

function node(tag, text) {
  const element = document.createElement(tag);
  element.textContent = text;
  return element;
}

function status(message) {
  el('status').textContent = message;
}

async function api(path = '/api/events', payload) {
  const headers = {Authorization: 'Bearer '+key};
  const options = {headers, cache: 'no-store'};
  if (payload) {
    headers['Content-Type'] = 'application/json';
    options.method = 'POST';
    options.body = JSON.stringify(payload);
  }
  const response = await fetch(path, options);
  if (!response.headers.get('Content-Type')?.includes('application/json')) {
    throw Error('Open this page from the address shown by run.py.');
  }
  const result = await response.json();
  if (!response.ok) throw Error(result.error || 'Request failed.');
  return result;
}

function identity({type, title, language}) {
  return JSON.stringify([type, title, language].map(value => value.trim().toLowerCase()));
}

function searchText(record) {
  return [record.title, record.artist, record.language, record.roles].join(' ').toLowerCase();
}

function validDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(value+'T00:00:00Z');
  return Number.isFinite(+parsed) && parsed.toISOString().slice(0,10)===value;
}

function drawOverview() {
  const counts = Object.fromEntries(Object.keys(types).map(type => [type, 0]));
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'
  }).formatToParts(new Date());
  const dateParts = Object.fromEntries(parts.map(part => [part.type, part.value]));
  const beginning = new Date(dateParts.year+'-'+dateParts.month+'-'+dateParts.day+'T00:00:00Z');
  const end = new Date(+beginning + 7 * 86400000);
  const upcoming = [];
  for (const {record} of records) {
    if (Object.hasOwn(counts,record.type)) counts[record.type]++;
    if (!validDate(record.date)) continue;
    const original = new Date(record.date+'T00:00:00Z');
    for (let year = beginning.getUTCFullYear(); year <= end.getUTCFullYear(); year++) {
      if (year < original.getUTCFullYear() || (record.type === 'event' && year !== original.getUTCFullYear())) continue;
      const day = new Date(year+record.date.slice(4)+'T00:00:00Z');
      if (day >= beginning && day <= end && day.getUTCMonth() === original.getUTCMonth()) upcoming.push([day, record.title]);
    }
  }
  el('summary').replaceChildren(node('li',records.length+' total'),
    ...Object.entries(counts).map(([type, count]) => node('li',types[type]+' · '+count)));
  upcoming.sort((a,b) => a[0]-b[0] || a[1].localeCompare(b[1]));
  el('upcoming-title').textContent = upcoming.length+' upcoming through the next 7 days';
  el('upcoming').replaceChildren(...upcoming.slice(0,20)
    .map(([when, title]) => node('li',when.toISOString().slice(0,10)+' · '+title)));
  if (upcoming.length > 20) el('upcoming').append(node('li','See Calendar for all upcoming records.'));
}

function draw() {
  const term = el('query').value.trim().toLowerCase();
  const kind = el('kind').value;
  const matches = records.filter(({record}) => (!kind || record.type===kind) && searchText(record).includes(term));
  page = Math.min(page,Math.max(0,Math.ceil(matches.length/pageSize)-1));
  const start = page*pageSize;
  el('page-count').textContent = matches.length
    ? (start+1)+'–'+Math.min(start+pageSize,matches.length)+' of '+matches.length
    : 'No matching records';
  el('previous').disabled = page===0;
  el('next').disabled = start+pageSize>=matches.length;
  el('results').replaceChildren(...matches.slice(start,start+pageSize).map(item => {
    const {record} = item;
    const button = node('button',record.title || 'Untitled record');
    button.setAttribute('aria-pressed',String(current===item));
    button.append(node('small',[types[record.type] || record.type, record.language, record.date].filter(Boolean).join(' · ')));
    button.onclick = () => edit(item,true);
    return button;
  }));
}

function updateLabels() {
  const type = entry.elements.type.value;
  const credit = {birth:'Display name or credit',film:'Director, cast or other credits',music:'Singer, composer or other credits'};
  const date = {birth:'Birth date',film:'Movie release date',music:'Music release date',milestone:'Achievement date'};
  el('credit-label').firstChild.nodeValue = (credit[type] || 'Artist or credit')+' ';
  el('date-label').firstChild.nodeValue = (date[type] || 'Event date')+' ';
}

function edit(item, focus = false) {
  current = item;
  entry.reset();
  if (item) {
    for (const input of entry.elements) {
      if (!input.name) continue;
      const value = item.record[input.name] || '';
      if (input.type==='checkbox') input.checked = value.toLowerCase()==='true';
      else input.value = value;
    }
  } else if (el('kind').value) entry.elements.type.value = el('kind').value;
  el('editor-title').textContent = item ? 'Edit record' : 'New record';
  el('delete').hidden = !item;
  updateLabels();
  draw();
  if (focus) entry.elements.title.focus();
}

async function load() {
  const result = await api();
  records = result.records;
  fields = result.fields;
  drawOverview();
}

function report(title, lines, empty) {
  el('report-title').textContent = title;
  el('report-count').textContent = lines.length ? lines.length+' entries' : empty;
  el('report-list').replaceChildren(...lines.map(line => node('li',line)));
  el('report').hidden = false;
  el('report-title').focus();
}

async function mutate(payload, message) {
  workspace.disabled = true;
  el('logout').disabled = true;
  status('Working…');
  try {
    const result = await api('/api/events',payload);
    const confirmation = typeof message==='function' ? message(result) : message;
    try {
      await load();
      edit(null);
      el('report').hidden = true;
    } catch (error) {
      status(confirmation+' Reload the editor for current records. '+error.message);
      return;
    }
    status([confirmation,result.warning].filter(Boolean).join(' '));
  } catch (error) {
    status(error.message+' If a record changed, sign out and unlock admin again to reload.');
  } finally {
    workspace.disabled = false;
    el('logout').disabled = false;
  }
}

el('kind').append(new Option('All types',''));
for (const [value,label] of Object.entries(types)) {
  el('kind').append(new Option(label,value));
  entry.elements.type.append(new Option(label,value));
}
entry.elements.type.onchange = updateLabels;
el('kind').onchange = el('query').oninput = () => { page=0; draw(); };
el('previous').onclick = () => { page--; draw(); };
el('next').onclick = () => { page++; draw(); };
el('new').onclick = () => edit(null,true);
el('login').onsubmit = async event => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button');
  button.disabled = true;
  key = el('key').value.trim();
  try {
    await load();
    el('key').value = '';
    el('gate').hidden = true;
    el('logout').hidden = false;
    workspace.hidden = false;
    edit(null);
    el('kind').focus();
    status('');
  } catch (error) {
    key = '';
    status(error.message);
  } finally {
    button.disabled = false;
  }
};
el('logout').onclick = () => {
  key = '';
  records = [];
  fields = [];
  current = null;
  page = 0;
  el('query').value = '';
  el('kind').value = '';
  el('file').value = '';
  el('report').hidden = true;
  el('report-list').replaceChildren();
  el('summary').replaceChildren();
  el('upcoming').replaceChildren();
  edit(null);
  workspace.hidden = true;
  el('logout').hidden = true;
  el('gate').hidden = false;
  el('key').focus();
  status('Signed out.');
};
entry.onsubmit = event => {
  event.preventDefault();
  mutate({action:'save',original:current,event:Object.fromEntries(new FormData(entry))},'Record saved.');
};
el('delete').onclick = () => {
  if (current && confirm('Delete '+current.record.title+'?')) {
    mutate({action:'delete',original:current},'Record deleted.');
  }
};
el('import').onsubmit = async event => {
  event.preventDefault();
  const file = el('file').files[0];
  if (!file || file.size > 3_000_000) return status('Choose a CSV file under 3 MB.');
  if (!confirm('Import '+file.name+' into the project catalogue?')) return;
  try {
    const csv = await file.text();
    await mutate({action:'import',csv},result => result.added+' added · '+result.skipped+' duplicates skipped.');
    el('file').value = '';
  } catch (error) { status(error.message); }
};
el('export').onclick = () => {
  const cell = value => {
    const safe = String(value ?? '').replace(/^[\s]*[=+@-]/,match => "'"+match);
    return '"'+safe.replaceAll('"','""')+'"';
  };
  const csv = [fields.map(cell).join(','),...records.map(({record}) => fields.map(field => cell(record[field])).join(','))].join('\r\n');
  const url = URL.createObjectURL(new Blob(['\uFEFF',csv],{type:'text/csv;charset=utf-8'}));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Divo_Export.csv';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url),1000);
};
el('quality').onclick = () => {
  const counts = new Map();
  for (const {record} of records) {
    const key = identity(record);
    counts.set(key,(counts.get(key)||0)+1);
  }
  const issues = records.flatMap(({record}) => {
    const problems = [
      !Object.hasOwn(types,record.type) && 'Unknown record type',
      !record.title.trim() && 'Missing title',
      !record.artist.trim() && 'Missing artist or credit',
      !record.language.trim() && 'Missing language',
      !validDate(record.date) && 'Missing or invalid date',
      counts.get(identity(record))>1 && 'Duplicate type, title and language'
    ].filter(Boolean);
    return problems.length ? [(record.title || 'Untitled')+' · '+record.language+' — '+problems.join(', ')] : [];
  });
  report('Data quality',issues,'No issues found.');
};
el('history').onclick = async () => {
  try {
    const entries = await api('/api/history');
    if (!key) return;
    report('Recent activity',entries.map(({time,action,detail}) =>
      new Date(time).toLocaleString()+' · '+action+' · '+detail),'No activity yet.');
  } catch (error) { status(error.message); }
};

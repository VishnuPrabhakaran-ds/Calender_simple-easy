# Divo Music Calendar

Use the top-level files for the local calendar. Use the separate files in `Apps_Script/` for the Google Sheets version with shared persistence. See [README.md](README.md) for local setup.

## Deploy with Google Sheets and Apps Script

1. Create a Google Sheet in Divo's Workspace. Open **Extensions → Apps Script** from that sheet.
2. Copy `Apps_Script/Code.gs` into the script project. Create an HTML file called `index` and copy in `Apps_Script/index.html`. This version embeds the Divo logo so it can run without a separate web server.
3. Under **Project Settings → Script properties**, set the values below. Credentials stay on the server.
4. From the Apps Script editor, run `setup_` as the deployment owner and approve permissions. It creates the Events tab or adds the three new fields to the previous calendar version, for the one-time import.
5. Choose **Deploy → New deployment → Web app**. For an internal team deployment, run as the deployer and restrict access to the Divo Workspace. Confirm the owner and a second authorised same-domain account can open the web app, and that only addresses in `ADMIN_EMAILS` see and can use Admin. Apps Script can withhold a visitor's email in some deployment contexts. Admin access fails closed when the email is unavailable. If that happens, use a Workspace configuration where Apps Script can access the visitor's identity. If deploying as the accessing user, grant the appropriate Sheet permissions separately and check them with both a viewer and an admin.
6. Open the deployed URL and choose **Admin → Import watchlist CSV**. Import the bundled `data/Divo_Import.csv` or an approved catalogue with the same headers. The server accepts up to 10,000 rows per import, skips duplicate type/title/language combinations, and rejects malformed records before writing. Edit or delete an existing record through Admin.
7. Test with an allowlisted account and a regular viewer. Verify that browsing works for both, only the admin can manage records, and a test edit is visible in a fresh browser session. The app has no public account form. Access to a Workspace-restricted deployment can still require Google's sign-in. [Web app deployment](https://developers.google.com/apps-script/guides/web) · [Active user identity](https://developers.google.com/apps-script/reference/base/session)
8. Admin can export the editable catalogue columns, review missing data and duplicates, and browse the latest 100 events in the **Admin Activity** sheet. That sheet is created on the first logged change. It records create, edit, delete and import actions with the available Workspace account. Direct edits in Sheets and background source refreshes are outside this history. The history is editable by Sheet editors.

For a previous deployment with weekly digests installed, remove its old time-driven digest trigger in the Apps Script project that owns it and remove or retire that digest script or deployment. This ZIP contains no notification sender. Existing triggers in your Google account are managed separately.

| Script property | Value |
| --- | --- |
| `ADMIN_EMAILS` | Comma-separated Workspace addresses allowed to administer events. |
| `WIKI_CONTACT` | Team contact email or URL for Wikimedia API identification. Set this to enable Wikipedia artwork refreshes. |
| `TMDB_TOKEN` | TMDB API Read Access Token for the team's approved use. Set this to enable TMDB lookups. |
| `TMDB_LOGO_URL` | HTTPS URL of an approved TMDB logo from its branding assets. Set this alongside TMDB access. |

## How enrichment works

- **Wikipedia** looks up an exact English article title and pulls available Commons artwork with supported licence metadata. The card links to the article and the file attribution page. Enter an approved thumbnail URL to override it. Follow any applicable attribution and licence requirements when using the artwork.
- **TMDB (The Movie Database)** uses a person ID for birthdays or a movie ID for films. It supplies available posters or profile photos and takes priority for date sync when enabled and an exact date is available. Its movie date is the date returned by TMDB's movie details endpoint. Use a manual date for a specific regional premiere or another release. Follow the [TMDB terms and branding guidance](https://developer.themoviedb.org/docs/faq) before using its API or artwork in the Divo deployment.
- **IMDb** IDs link to the source page and can be resolved through TMDB to find a matching film or person. Direct IMDb data would need [separate IMDb API access](https://data.imdb.com/documentation/api-documentation/getting-access/).
- **Date extraction** uses the Wikipedia page’s Wikidata item when date sync is enabled. It accepts one unambiguous day-level birthday or publication date. Conflicting, incomplete, or missing dates fall back to an editor-entered date. Leave date sync off to preserve a verified release date for a specific market or version.
- **Music releases** use the song or soundtrack’s own release date. If Wikidata has no exact day, use a source-checked date from the article or from the label’s records. Supply eligible Wikipedia artwork or an approved image URL. The calendar prefers the approved image, then eligible Wikipedia artwork, then TMDB artwork. Missing images display initials.
- **Scope.** This refreshes events that admins add. Add historical events as rows through Admin or import them using the Events headers. Give each imported row a unique ID and use `YYYY-MM-DD` text dates. The starter watchlist covers Tamil, Telugu, Malayalam and Kannada examples. It does not establish Divo rights or represent the complete roster. Use the Divo watchlist to define coverage. Any date that has neither a confirmed source date nor a manual fallback stays pending.

The Apps Script HTML uses an embedded logo and `google.script.run` for Sheets calls. Apply public design changes to both HTML files where applicable. Publish changes by deploying a new Apps Script version. Test against a copy of the sheet before updating an existing deployment. Formula-like values are escaped in downloads. Use a copy of the Sheet for a full backup, including enriched fields and history.

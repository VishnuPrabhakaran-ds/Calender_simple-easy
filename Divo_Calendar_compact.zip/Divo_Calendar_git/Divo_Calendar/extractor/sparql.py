from urllib.request import Request,urlopen
from urllib.parse import urlencode
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.error import HTTPError
import math
import random
import time
import json
from os import environ
prefix='''PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX p: <http://www.wikidata.org/prop/>
PREFIX psv: <http://www.wikidata.org/prop/statement/value/>
PREFIX wikibase: <http://wikiba.se/ontology#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX schema: <http://schema.org/>
PREFIX bd: <http://www.bigdata.com/rdf#>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
'''
def retry_delay(header, attempt):
    fallback = 30 * 2 ** attempt + random.randint(0, 5)
    if header:
        try:
            seconds = int(header)
        except ValueError:
            try:
                when = parsedate_to_datetime(header)
                seconds = math.ceil((when - datetime.now(timezone.utc)).total_seconds())
            except (ValueError, TypeError, OverflowError):
                return fallback
        return max(seconds, fallback)
    return fallback


def query(body):
    url = 'https://qlever.dev/api/wikidata?' + urlencode({'query': prefix + body})
    request = Request(url, headers={
        'Accept': 'application/sparql-results+json',
        'User-Agent': environ.get('DIVO_WIKI_USER_AGENT', 'DivoMusicCalendar/1.1 (historical catalogue import)')
    })
    for attempt in range(5):
        try:
            with urlopen(request, timeout=55) as response:
                return json.load(response)['results']['bindings']
        except HTTPError as error:
            with error:
                if error.code not in (429, 503):
                    raise
                delay = retry_delay(error.headers.get('Retry-After'), attempt)
                if attempt == 4 or delay > 900:
                    raise RuntimeError(f'QLever returned HTTP {error.code}. Wait at least {delay} seconds before resuming.') from error
                print(f'QLever returned HTTP {error.code}. Retrying in {delay} seconds (attempt {attempt + 2}/5).', flush=True)
            time.sleep(delay)

# Run the Divo calendar extraction in VS Code

Install Python 3.8 or newer. Unzip the project and use File → Open Folder in VS Code. Select the extracted folder that contains snapshot.py. Open Terminal → New Terminal.

On Windows, run:

    py --version
    py snapshot.py --start 1990 --output data

On macOS or Linux, run:

    python3 --version
    python3 snapshot.py --start 1990 --output data

No pip packages or API keys are required. The script makes a one-time query of Wikidata through QLever. By default, it includes releases through the day you run it. Birthdays of credited people can predate 1990.

Use --end 1999 to run the 1990s alone. Choose a distinct output folder for each date range. For a fresh full extraction, use --output data_fresh. If a request fails, rerun the same command to reuse the completed queries. Check Coverage.json for errors before importing.

- data/Divo_Import.csv contains the calendar-ready records. Import it through Admin → Import watchlist CSV in the deployed calendar.
- data/Source_Records.csv contains reference links for the CSV rows.
- data/Dates_to_review.csv contains discovered records with conflicting dates.
- data/Coverage.json contains row counts and any extraction errors.

The query covers Tamil, Telugu, Malayalam and Kannada films, music and linked contributors. Calendar rows require an exact date. Public coverage varies by language and period, especially for older songs. IMDb and TMDB identifiers are included where available in the source records. The included Divo_Watchlist.csv supplies the existing starter entries.

If you saw HTTP 429 (Too Many Requests), stop the old run and replace snapshot.py and sparql.py in your existing project. Keep the data folder. Run one copy of the command. The updated extractor sends requests one at a time, waits between attempts, and respects the server's Retry-After delay. It stops after repeated failures or a requested wait over 15 minutes. Follow the printed wait time before restarting. Cached queries are reused for the same output folder and exact date range, including the cutoff day. A stopped download leaves previous CSV exports in place.

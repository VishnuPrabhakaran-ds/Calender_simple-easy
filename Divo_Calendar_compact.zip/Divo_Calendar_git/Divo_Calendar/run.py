"""Serve the public calendar and its key-protected, loopback-only catalogue editor."""
import csv
from datetime import date, datetime, timezone
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import re
import secrets
import tempfile
import threading
from urllib.parse import urlsplit
import webbrowser

ROOT = Path(__file__).resolve().parent
CATALOGUE = ROOT / 'data' / 'Divo_Import.csv'
HISTORY = ROOT / 'data' / 'Admin_Activity.jsonl'
FIELDS = 'type title artist language date wikiTitle tmdbId imdbId imageOverride syncDate roles'.split()
TYPES = {'birth', 'music', 'film', 'event', 'milestone'}
LANGUAGES = {'Tamil', 'Telugu', 'Malayalam', 'Kannada'}
PUBLIC = {'/', '/index.html', '/admin.html', '/admin.js', '/divo-music-logo.jpg', '/data/Divo_Import.csv'}
LOCK = threading.Lock()


def admin_key():
    folder = Path.home() / '.divo-calendar'
    folder.mkdir(mode=0o700, exist_ok=True)
    path = folder / 'admin-key.txt'
    if not path.exists():
        with tempfile.NamedTemporaryFile(dir=folder, delete=False) as temp:
            temp.write(secrets.token_urlsafe(24).encode('ascii'))
            prepared = Path(temp.name)
        try:
            os.link(prepared, path)
        except FileExistsError:
            pass
        finally:
            prepared.unlink()
    key = path.read_text(encoding='utf-8-sig').strip()
    if not key or not key.isascii() or not key.isprintable():
        raise SystemExit(f'Enter a key on one line in {path} and restart.')
    return key


def identity(row):
    return tuple(row[field].strip().casefold() for field in ('type', 'title', 'language'))


def revision(row):
    return hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest()


def read_csv(stream):
    reader = csv.DictReader(stream, strict=True)
    fields = reader.fieldnames or []
    if not set(FIELDS).issubset(fields) or len(fields) != len(set(fields)) or '' in fields:
        raise ValueError('Use unique CSV headers including every column in Divo_Import.csv.')
    rows = []
    for row in reader:
        if None in row or None in row.values():
            raise ValueError(f'CSV line {reader.line_num} has the wrong number of columns.')
        rows.append(row)
    return fields, rows


def catalogue():
    if not CATALOGUE.exists():
        return FIELDS, []
    with CATALOGUE.open(encoding='utf-8-sig', newline='') as stream:
        return read_csv(stream)


class Conflict(ValueError):
    pass


def validate(row):
    if not isinstance(row, dict) or any(not isinstance(value, str) for value in row.values()):
        raise ValueError('Record fields must contain text.')
    if any(len(value) > 2000 for value in row.values()):
        raise ValueError('Keep each record field under 2,001 characters.')
    updates = {field: row.get(field, '').strip() for field in FIELDS}
    if updates['type'] not in TYPES or not updates['title']:
        raise ValueError('Choose a record type and enter a title.')
    if updates['language'] not in LANGUAGES:
        raise ValueError('Choose a supported language.')
    try:
        value = updates['date']
        if date.fromisoformat(value).isoformat() != value:
            raise ValueError()
    except ValueError:
        raise ValueError('Enter a valid date in YYYY-MM-DD format.') from None
    if updates['imageOverride']:
        image = urlsplit(updates['imageOverride'])
        if image.scheme != 'https' or not image.hostname or any(c.isspace() for c in updates['imageOverride']):
            raise ValueError('Enter a valid HTTPS artwork URL.')
    if updates['tmdbId'] and not re.fullmatch(r'[0-9]{1,12}', updates['tmdbId']):
        raise ValueError('Enter a numeric TMDB ID.')
    if updates['imdbId'] and not re.fullmatch(r'(tt|nm)[0-9]{1,12}', updates['imdbId']):
        raise ValueError('Enter an IMDb ID starting with tt or nm.')
    updates['syncDate'] = 'true' if updates['syncDate'].lower() == 'true' else 'false'
    return updates


def write_catalogue(fields, rows):
    CATALOGUE.parent.mkdir(exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=CATALOGUE.parent, delete=False) as temp:
        name = Path(temp.name)
    try:
        with name.open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
        os.replace(name, CATALOGUE)
    finally:
        name.unlink(missing_ok=True)


def log_activity(action, detail):
    entry = {'time': datetime.now(timezone.utc).isoformat(timespec='seconds'),
             'action': action, 'detail': detail}
    try:
        with HISTORY.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(entry, ensure_ascii=False) + '\n')
        return {}
    except OSError:
        return {'warning': 'Catalogue saved, but activity history could not be written.'}


def recent_activity():
    if not HISTORY.exists():
        return []
    from collections import deque
    with HISTORY.open(encoding='utf-8') as stream:
        lines = deque(stream, maxlen=100)
    entries = []
    for line in reversed(lines):
        try:
            entries.append(json.loads(line))
        except ValueError:
            continue
    return entries


def update_catalogue(payload):
    fields, rows = catalogue()
    action = payload.get('action', 'save')
    if action == 'import':
        source = payload.get('csv')
        if not isinstance(source, str):
            raise ValueError('Choose a CSV file.')
        incoming_fields, incoming = read_csv(io.StringIO(source.lstrip('\ufeff'), newline=''))
        if not 1 <= len(incoming) <= 10000:
            raise ValueError('Import between 1 and 10,000 records at a time.')
        keys = {identity(row) for row in rows}
        pending = []
        for index, row in enumerate(incoming, start=2):
            try:
                record = {**row, **validate(row)}
            except ValueError as error:
                raise ValueError(f'CSV record {index}: {error}') from error
            key = identity(record)
            if key not in keys:
                pending.append(record)
                keys.add(key)
        added, skipped = len(pending), len(incoming) - len(pending)
        result = {'added': added, 'skipped': skipped}
        if added:
            fields = list(dict.fromkeys(fields + incoming_fields))
            write_catalogue(fields, rows + pending)
            result.update(log_activity('Import', f'{added} added, {skipped} duplicates skipped'))
        return result

    if action not in ('save', 'delete'):
        raise ValueError('Unknown operation.')
    original = payload.get('original')
    index = None
    if original is not None:
        if not isinstance(original, dict):
            raise ValueError('Invalid original record.')
        index = original.get('position')
        if (type(index) is not int or not 0 <= index < len(rows)
                or revision(rows[index]) != original.get('revision')):
            raise Conflict('The catalogue changed. Reload and select the record again.')
    if action == 'delete':
        if index is None:
            raise ValueError('Select a record to delete.')
        record = rows.pop(index)
        label = 'Delete'
    else:
        updates = validate(payload.get('event'))
        key = identity(updates)
        if (index is None or key != identity(rows[index])) and any(
                identity(row) == key for i, row in enumerate(rows) if i != index):
            raise Conflict('A record with this type, title and language already exists.')
        if index is None:
            record = updates
            rows.append(record)
            label = 'Create'
        else:
            record = rows[index]
            record.update(updates)
            label = 'Edit'
    write_catalogue(fields, rows)
    return {'saved': True, **log_activity(label, f"{record['title']} ({record['type']}, {record['language']})")}


class Handler(SimpleHTTPRequestHandler):
    def send_head(self):
        if urlsplit(self.path).path not in PUBLIC:
            self.send_error(404)
            return None
        return super().send_head()

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        super().end_headers()

    def reply(self, status, result):
        body = json.dumps(result, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def authorized(self):
        header = self.headers.get('Authorization', '')
        if secrets.compare_digest(header.encode(), ('Bearer ' + self.server.admin_key).encode()):
            return True
        self.reply(403, {'error': 'Enter the admin key printed by run.py.'})
        return False

    def do_GET(self):
        if self.path not in ('/api/events', '/api/history'):
            return super().do_GET()
        if not self.authorized():
            return
        try:
            with LOCK:
                if self.path == '/api/history':
                    result = recent_activity()
                else:
                    fields, rows = catalogue()
                    result = {'fields': fields, 'records': [
                        {'record': row, 'position': index, 'revision': revision(row)}
                        for index, row in enumerate(rows)
                    ]}
            self.reply(200, result)
        except (ValueError, OSError, csv.Error) as error:
            self.reply(400, {'error': str(error)})

    def do_POST(self):
        if self.path != '/api/events':
            return self.send_error(404)
        if not self.authorized():
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if self.headers.get_content_type() != 'application/json' or not 0 < length <= 8_000_000:
                raise ValueError('Send JSON under 8 MB.')
            payload = json.loads(self.rfile.read(length))
            if not isinstance(payload, dict):
                raise ValueError('Invalid request.')
            with LOCK:
                result = update_catalogue(payload)
            self.reply(200, result)
        except Conflict as error:
            self.reply(409, {'error': str(error)})
        except (ValueError, OSError, csv.Error) as error:
            self.reply(400, {'error': str(error)})


def main():
    key = admin_key()
    handler = partial(Handler, directory=str(ROOT))
    try:
        server = ThreadingHTTPServer(('127.0.0.1', 8765), handler)
    except OSError:
        server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    with server:
        server.admin_key = key
        url = f'http://127.0.0.1:{server.server_port}/'
        print(f'Calendar: {url}\nAdmin key: {key}\nPress Ctrl+C to stop.', flush=True)
        webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()

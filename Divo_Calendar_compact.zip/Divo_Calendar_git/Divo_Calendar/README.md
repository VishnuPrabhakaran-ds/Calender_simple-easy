# Divo Music Calendar

1. Extract the ZIP and open the inner folder containing `run.py`.
2. Run `python run.py` from that folder. You can also open it in VS Code and choose **Run Python File in Terminal**. No packages are required.
3. Open the address printed in the terminal if the browser does not open automatically. Leave the terminal running while using the calendar. Press Ctrl+C to stop.

The calendar, its expandable agenda and the artist directory use the included `data/Divo_Import.csv`. Agenda preparation marks are stored in this browser. Browsing the local calendar requires no account.

## Local administration

Click **Admin** and enter the key printed by `run.py`. The Python server checks the key on every admin API request and listens only on this computer. The key is stored at `~/.divo-calendar/admin-key.txt`. This mode uses a shared local key and has no named admin accounts.

- Use **Catalogue overview** for counts by type and upcoming events.
- Add, search, edit or delete calendar events, artist birthday/profile records, music releases, movie releases and career milestones. Add singers, composers, directors or performers in the credit and roles fields. Music records use one row per song, album or soundtrack release. General calendar events occur once. Birthdays, releases and career milestones recur annually.
- Import using the columns in `data/Divo_Import.csv`. Import adds records and skips duplicate type, title and language combinations. A malformed record rejects the whole batch. Edit an existing row to change it. The local editor accepts up to 10,000 rows and 3 MB of CSV per upload.
- Export a spreadsheet-friendly CSV. Formula-like values receive an apostrophe prefix. For an exact backup, copy `data/Divo_Import.csv` directly.
- **Data quality** reports missing information and duplicate identities. **Activity history** displays the latest 100 changes saved to `data/Admin_Activity.jsonl`. This file records local actions and has no verified actor identity or tamper protection.

Edits persist to the project CSV. Refresh an already open public page to load them. The extractor can replace the CSV, so back it up before regenerating and avoid running the extractor and the editor against the same file at the same time. The optional extractor and its source and coverage files are included.

## Demo and shared deployment

Opening `index.html` directly shows the built-in sample dataset. Start `run.py` for the full project catalogue and working local admin. Serving the files on a static web host can display the CSV, but admin writes require a running backend.

For a shared Google Sheets deployment, use the files and instructions in [Apps Script setup](Apps_Script_Setup.md). That version stores edits in Sheets and checks the Workspace admin allowlist on the server. Its deployment and account permissions must be configured and tested in your Workspace.
